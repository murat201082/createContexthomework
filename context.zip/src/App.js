import "./App.css";
import InputComponent from "./InputComponent";

function App() {
  return (
    <div className="App">
      <InputComponent />
    </div>
  );
}

export default App;
